"""
[담당: 희선]
전체 연결 책임자. 3개 에이전트를 순서대로 호출하고,
Critic 에이전트로 최종 검증 + 신뢰도 계산까지 마쳐서 응답.

실행: uvicorn main:app --reload
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from schemas import StockAnalysisResponse
from services import data_service, sentiment_service, prediction_service
import critic

app = FastAPI(title="주식 리서치 MVP")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/analyze", response_model=StockAnalysisResponse)
def analyze(ticker: str = "005930.KS"):
    try:
        # 1. 뉴스 에이전트 — 정보 불확실성 스스로 판단
        data_result = data_service.get_stock_data(ticker)

        # 2. 감성 에이전트 — 감성 불확실성 스스로 판단
        sentiment_result = sentiment_service.analyze(data_result.news)

        # 3. 예측 에이전트 — 감성 반영 + 예측 불확실성 스스로 판단
        prediction_result = prediction_service.predict(
            ticker, data_result.price, sentiment_result.sentiment
        )

        # 4. Critic 에이전트 — 셋을 모으고 모순 검증 + 최종 신뢰도 산출
        warnings, confidence_score = critic.review(
            data_result, sentiment_result, prediction_result
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    return StockAnalysisResponse(
        ticker=data_result.ticker,
        price=data_result.price,
        news=data_result.news,
        prediction=prediction_result.prediction,
        sentiment=sentiment_result.sentiment,
        warnings=warnings,
        confidence_score=confidence_score,
        explanation=sentiment_result.explanation,
    )
