"""
[파인튜닝 데이터 준비 도구 — 연우]

NewsAPI로 종목/섹터 관련 뉴스를 모으고, Claude API로 초벌 감성 라벨을 매겨서
CSV로 출력. 팀은 이 CSV를 빠르게 검토·수정만 하면 됨 (처음부터 라벨링 X).

이건 메인 파이프라인이 아니라 "파인튜닝 데이터 준비용" 1회성 도구임.

실행: python tools/build_finetune_dataset.py
출력: tools/finetune_dataset_draft.csv  (팀이 검토할 파일)
"""
import os
import csv
import time
from datetime import datetime, timedelta
from newsapi import NewsApiClient
import anthropic

NEWS_API_KEY = os.getenv("NEWS_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

# 라벨링하고 싶은 섹터/키워드 — 필요에 맞게 수정
SEARCH_KEYWORDS = [
    "반도체",
    "삼성전자",
    "SK하이닉스",
    "HBM",
    "온디바이스 AI",
]

NEWS_PER_KEYWORD = 20  # 키워드당 수집할 뉴스 수


def collect_headlines() -> list[dict]:
    """NewsAPI로 키워드별 최근 뉴스 헤드라인 수집"""
    client = NewsApiClient(api_key=NEWS_API_KEY)
    all_articles = []

    for keyword in SEARCH_KEYWORDS:
        try:
            result = client.get_everything(
                q=keyword,
                from_param=(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"),
                language="ko",
                sort_by="relevancy",
                page_size=NEWS_PER_KEYWORD,
            )
            for article in result.get("articles", []):
                all_articles.append({
                    "keyword": keyword,
                    "title": article["title"],
                    "source": article["source"]["name"],
                })
        except Exception as e:
            print(f"[수집 오류] {keyword}: {e}")

    # 중복 제거 (같은 제목)
    seen = set()
    unique_articles = []
    for a in all_articles:
        if a["title"] not in seen:
            seen.add(a["title"])
            unique_articles.append(a)

    return unique_articles


def label_with_claude(title: str, client: anthropic.Anthropic) -> str:
    """Claude로 초벌 감성 라벨 생성 — positive/negative/neutral 중 하나"""
    prompt = f"""다음 금융 뉴스 제목의 감성을 분류해줘. 반드시 아래 세 단어 중 하나만 답해.

제목: "{title}"

positive, negative, neutral 중 하나만 출력. 다른 말은 하지 마."""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=10,
        messages=[{"role": "user", "content": prompt}],
    )
    label = message.content[0].text.strip().lower()

    if label not in ("positive", "negative", "neutral"):
        label = "neutral"  # 예상 밖 응답이면 안전하게 중립 처리
    return label


def main():
    print("1. NewsAPI에서 헤드라인 수집 중...")
    articles = collect_headlines()
    print(f"   → {len(articles)}개 수집 완료")

    print("2. Claude로 초벌 라벨링 중... (시간이 좀 걸려요)")
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    rows = []
    for i, article in enumerate(articles):
        label = label_with_claude(article["title"], client)
        rows.append({
            "title": article["title"],
            "keyword": article["keyword"],
            "source": article["source"],
            "draft_label": label,
            "verified_label": "",  # 팀이 검토 후 여기에 최종 라벨 입력
        })
        print(f"   [{i+1}/{len(articles)}] {label}: {article['title'][:30]}...")
        time.sleep(0.3)  # API 속도 제한 방지

    output_path = os.path.join(os.path.dirname(__file__), "finetune_dataset_draft.csv")
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["title", "keyword", "source", "draft_label", "verified_label"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n완료! {output_path} 파일을 열어서:")
    print("  1. draft_label이 맞는지 훑어보기")
    print("  2. 틀린 것만 verified_label에 올바른 값(positive/negative/neutral) 입력")
    print("  3. 맞는 건 verified_label에 draft_label 그대로 복사")


if __name__ == "__main__":
    main()
