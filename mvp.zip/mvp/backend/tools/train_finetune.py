"""
[감성 에이전트 파인튜닝 — 연우]

✅ 추천: finance_data.csv (이미 포함됨) — Finance PhraseBank 한국어 번역본
   4,846개 라벨링된 금융 문장 (positive/neutral/negative), 검수 완료.
   출처: https://github.com/ukairia777/finance_sentiment_corpus
   바로 사용 가능 — 직접 라벨링 안 해도 됨!

   사용: python train_finetune.py --csv finance_data.csv

대안: build_finetune_dataset.py로 직접 모은 최신 이슈 데이터 (시간 있을 때 보너스)

✅ Colab에서 실행 (GPU 런타임 필수 — 런타임 > 런타임 유형 변경 > T4 GPU)

⚠️ 중요: snunlp/KR-FinBert는 "분류기 헤드가 없는" 베이스 인코더임
   (감성분석을 하려면 분류기를 처음부터 새로 학습해야 함).
   실제 감성 분류기가 이미 붙어있는 버전은 snunlp/KR-FinBert-SC ("SC" = Sentence
   Classification). 이 스크립트는 KR-FinBert-SC를 사용해서 "파인튜닝 전"에도
   의미 있는 베이스라인 정확도가 나오도록 함.

Colab 설치:
!pip install transformers torch datasets scikit-learn pandas -q

실행: python train_finetune.py --csv finance_data.csv
"""
import argparse
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score

BASE_MODEL = "snunlp/KR-FinBert-SC"  # 분류기 헤드가 실제로 학습되어 있는 버전
LABEL_MAP = {"negative": 0, "neutral": 1, "positive": 2}
ID2LABEL = {v: k for k, v in LABEL_MAP.items()}


def load_and_split(csv_path: str, test_size: float = 0.2):
    """
    CSV 로드 → 학습/검증 분리.
    두 가지 형식 지원:
    ① 자체 수집 데이터: title, verified_label 컬럼
    ② Finance PhraseBank 한국어 번역본: kor_sentence, labels 컬럼
       (https://github.com/ukairia777/finance_sentiment_corpus)
    """
    df = pd.read_csv(csv_path)

    if "kor_sentence" in df.columns and "labels" in df.columns:
        # Finance PhraseBank 한국어 데이터 형식
        df = df.rename(columns={"kor_sentence": "title", "labels": "verified_label"})
    elif "title" not in df.columns or "verified_label" not in df.columns:
        raise ValueError(
            "CSV에 (title, verified_label) 또는 (kor_sentence, labels) 컬럼이 필요합니다."
        )

    df = df[df["verified_label"].isin(LABEL_MAP.keys())].copy()
    if len(df) < 10:
        raise ValueError(
            f"검증된 데이터가 {len(df)}개뿐입니다. "
            "verified_label 컬럼을 채운 행이 최소 10개 이상 필요합니다."
        )

    df["label"] = df["verified_label"].map(LABEL_MAP)

    train_df, val_df = train_test_split(
        df, test_size=test_size, random_state=42, stratify=df["label"]
    )
    return train_df[["title", "label"]], val_df[["title", "label"]]


def _normalize_label(raw_label: str) -> str | None:
    """
    모델마다 라벨 표기가 다를 수 있어서(positive/POS/LABEL_2 등) 표준 형식으로 변환.
    "LABEL_0" 같은 의미 불명 라벨이면 매핑 불가 → None 반환.
    """
    s = raw_label.lower()
    if "pos" in s:
        return "positive"
    if "neg" in s:
        return "negative"
    if "neu" in s:
        return "neutral"
    return None


def evaluate_baseline(val_df, model_name: str = BASE_MODEL):
    """
    파인튜닝 전 — 원본 모델이 이 데이터에서 얼마나 잘 맞는지 측정.
    이 점수와 파인튜닝 후 점수를 비교하면 "추가 학습이 실제로 도움이 됐는지" 확인 가능.

    모델에 분류기 헤드가 없거나 라벨 이름이 불명확하면, 잘못된 0% 같은 숫자
    대신 측정을 건너뛰고 None을 반환함 (틀린 숫자를 내는 것보단 안전함).
    """
    from transformers import pipeline

    print(f"베이스라인 측정 중 (파인튜닝 전 {model_name})...")
    pipe = pipeline("text-classification", model=model_name, top_k=None)

    # 모델이 실제로 어떤 라벨 이름을 쓰는지 먼저 확인
    sample_result = pipe("이것은 테스트 문장입니다")[0]
    raw_labels = [item["label"] for item in sample_result]
    print(f"   모델이 반환하는 라벨: {raw_labels}")

    if any(_normalize_label(l) is None for l in raw_labels):
        print("   ⚠️ 라벨을 positive/negative/neutral로 매핑할 수 없습니다.")
        print("   (분류기 헤드가 없거나 라벨이 의미 불명 — 베이스라인 측정을 건너뜁니다)")
        return None

    correct = 0
    for _, row in val_df.iterrows():
        result = pipe(row["title"][:512])[0]
        pred_raw = max(result, key=lambda x: x["score"])["label"]
        pred_label = _normalize_label(pred_raw)
        true_label = ID2LABEL[row["label"]]
        if pred_label == true_label:
            correct += 1

    accuracy = correct / len(val_df)
    print(f"베이스라인 정확도: {accuracy:.1%} ({correct}/{len(val_df)})")
    return accuracy


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    return {
        "accuracy": accuracy_score(labels, preds),
        "f1": f1_score(labels, preds, average="weighted"),
    }


def main(csv_path: str, output_dir: str = "./kr-finbert-finetuned", skip_baseline: bool = False):
    # 무거운 라이브러리는 함수 안에서 import (데이터 검증만 할 때는 불필요)
    from datasets import Dataset
    from transformers import (
        AutoTokenizer,
        AutoModelForSequenceClassification,
        TrainingArguments,
        Trainer,
    )

    print(f"1. 데이터 로드: {csv_path}")
    train_df, val_df = load_and_split(csv_path)
    print(f"   학습 {len(train_df)}개 / 검증 {len(val_df)}개")

    baseline_accuracy = None
    if not skip_baseline:
        print("\n--- 파인튜닝 전 베이스라인 측정 ---")
        # 검증셋이 크면 측정 시간이 오래 걸리니 일부만 샘플링
        sample = val_df.sample(min(200, len(val_df)), random_state=42)
        baseline_accuracy = evaluate_baseline(sample)

    train_ds = Dataset.from_pandas(train_df, preserve_index=False)
    val_ds = Dataset.from_pandas(val_df, preserve_index=False)

    print(f"\n2. 베이스 모델 로드: {BASE_MODEL}")
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
    model = AutoModelForSequenceClassification.from_pretrained(
        BASE_MODEL, num_labels=3, id2label=ID2LABEL, label2id=LABEL_MAP
    )

    def tokenize(batch):
        return tokenizer(batch["title"], truncation=True, padding="max_length", max_length=64)

    train_ds = train_ds.map(tokenize, batched=True)
    val_ds = val_ds.map(tokenize, batched=True)

    print("3. 파인튜닝 시작...")
    args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=3,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        learning_rate=2e-5,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        logging_steps=10,
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        compute_metrics=compute_metrics,
    )
    trainer.train()

    final_path = f"{output_dir}/final"
    print(f"4. 모델 저장: {final_path}")
    trainer.save_model(final_path)
    tokenizer.save_pretrained(final_path)

    final_metrics = trainer.evaluate()
    after_accuracy = final_metrics.get("eval_accuracy")

    print("\n" + "=" * 40)
    print("파인튜닝 전후 비교")
    print("=" * 40)
    if baseline_accuracy is not None:
        print(f"파인튜닝 전 ({BASE_MODEL}): {baseline_accuracy:.1%}")
        print(f"파인튜닝 후 (우리 데이터 추가 학습): {after_accuracy:.1%}")
        diff = after_accuracy - baseline_accuracy
        print(f"개선폭: {diff:+.1%}")
    else:
        print("파인튜닝 전: 측정 불가 (베이스 모델에 유효한 분류기가 없었음)")
        print(f"파인튜닝 후 (우리 데이터로 학습한 분류기): {after_accuracy:.1%}")
        print("→ 발표 시 '전후 비교'가 아니라 '우리가 학습시킨 분류기의 정확도'로 표현하세요.")
    print("=" * 40)

    print("\n완료! sentiment_service.py의 _get_pipe()에서 모델 경로를 다음으로 바꾸면 됨:")
    print(f'   pipeline("text-classification", model="{final_path}", top_k=None)')
    print("\n(Colab 세션이 끝나면 final_path는 사라지니, HuggingFace Hub에 업로드 추천)")
    print('   model.push_to_hub("your-username/kr-finbert-stock-finetuned")')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True, help="검증된 라벨 CSV 경로")
    parser.add_argument("--output", default="./kr-finbert-finetuned")
    parser.add_argument(
        "--skip-baseline", action="store_true",
        help="파인튜닝 전 베이스라인 측정을 건너뜀 (시간 절약, 비교 불가)"
    )
    args = parser.parse_args()
    main(args.csv, args.output, args.skip_baseline)
