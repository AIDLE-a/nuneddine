"""
[담당: 희선]
Prophet 기반 30일 주가 예측 + 감성 점수로 보정.
스스로 "예측 불확실성"을 판단해서 같이 반환.

✅ 감성 에이전트 결과가 먼저 나와야 이 함수를 호출할 수 있음 (순서 의존성 있음).
✅ 코랩에서 먼저 테스트한 로직을 _run_prophet()에 그대로 옮기면 됨.
"""
import os
from schemas import Prediction, PredictionResult, Sentiment

USE_MOCK = os.getenv("USE_MOCK_DATA", "true").lower() == "true"

SENTIMENT_ADJUSTMENT_WEIGHT = 0.02  # 감성이 예측에 영향을 줄 수 있는 최대 비율 (±2%)


def predict(ticker: str, price: float, sentiment: Sentiment) -> PredictionResult:
    """메인 함수 — 오케스트레이터가 이 함수만 호출함"""
    if USE_MOCK:
        base = _get_mock_prediction(price)
    else:
        base = _run_prophet(ticker, price)

    adjusted = _adjust_with_sentiment(base, sentiment)
    prediction_warning = _check_prediction_uncertainty(adjusted)

    return PredictionResult(prediction=adjusted, prediction_warning=prediction_warning)


def _run_prophet(ticker: str, price: float) -> Prediction:
    """TODO(희선): yfinance 1년치 데이터 + Prophet 30일 예측 (순수 가격 패턴만 사용)"""
    raise NotImplementedError


def _adjust_with_sentiment(prediction: Prediction, sentiment: Sentiment) -> Prediction:
    """감성 점수로 예측을 보정 (휴리스틱 보정, 정식 회귀모델 아님)"""
    sentiment_score = sentiment.positive - sentiment.negative
    adjustment = 1 + sentiment_score * SENTIMENT_ADJUSTMENT_WEIGHT

    return Prediction(
        future_price=round(prediction.future_price * adjustment, 1),
        lower=round(prediction.lower * adjustment, 1),
        upper=round(prediction.upper * adjustment, 1),
    )


def _check_prediction_uncertainty(prediction: Prediction) -> str | None:
    """예측 에이전트 스스로의 불확실성 판단 — 신뢰구간이 너무 넓은가?"""
    spread = prediction.upper - prediction.lower
    if spread / prediction.future_price > 0.1:
        return "변동성 높음"
    return None


def _get_mock_prediction(price: float) -> Prediction:
    return Prediction(
        future_price=price * 1.02,
        lower=price * 0.97,
        upper=price * 1.06,
    )
