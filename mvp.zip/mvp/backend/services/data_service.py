"""
[담당: 유빈]
yfinance + NewsAPI/RSS로 주가·뉴스 데이터를 수집.
스스로 "정보 불확실성"을 판단해서 같이 반환.

✅ 이 파일만 채우면 됨. 반환 형식(StockDataResult)은 절대 바꾸지 말 것.
"""
import os
import yfinance as yf
from datetime import datetime, timedelta
from schemas import StockDataResult, NewsItem

USE_MOCK = os.getenv("USE_MOCK_DATA", "true").lower() == "true"


def get_stock_data(ticker: str) -> StockDataResult:
    """메인 함수 — 오케스트레이터가 이 함수만 호출함"""
    if USE_MOCK:
        return _get_mock_data(ticker)

    price = _fetch_price(ticker)
    news = _fetch_news(ticker)
    info_warning = _check_info_uncertainty(news)

    return StockDataResult(ticker=ticker, price=price, news=news, info_warning=info_warning)


def _fetch_price(ticker: str) -> float:
    """TODO(유빈): yfinance로 실시간/최근 종가 가져오기"""
    stock = yf.Ticker(ticker)
    hist = stock.history(period="5d")
    if hist.empty:
        raise ValueError(f"{ticker} 주가 데이터를 가져올 수 없습니다")
    return float(hist["Close"].iloc[-1])


def _fetch_news(ticker: str) -> list[NewsItem]:
    """TODO(유빈): NewsAPI 또는 RSS로 최근 뉴스 수집"""
    return []


def _check_info_uncertainty(news: list[NewsItem]) -> str | None:
    """뉴스 에이전트 스스로의 불확실성 판단 — 정보가 충분한가?"""
    if len(news) < 5:
        return "뉴스 부족"
    return None


def _get_mock_data(ticker: str) -> StockDataResult:
    """다른 팀원들이 기다리지 않고 개발할 수 있게 만든 가짜 데이터"""
    news = [
        NewsItem(
            title="삼성전자, 차세대 반도체 양산 계획 발표",
            source="한국경제",
            url="https://example.com/news/1",
            published_at=datetime.now().isoformat(),
        ),
        NewsItem(
            title="반도체 업황 회복 기대감 확산",
            source="매경",
            url="https://example.com/news/2",
            published_at=(datetime.now() - timedelta(days=1)).isoformat(),
        ),
    ]
    return StockDataResult(
        ticker=ticker,
        price=72000,
        news=news,
        info_warning=_check_info_uncertainty(news),
    )
