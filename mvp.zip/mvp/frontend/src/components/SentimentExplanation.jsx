/**
 * [담당: 채민]
 * XAI 설명 레이어 — 백엔드 explanation 필드를 받아서
 * "왜 이런 감성 점수가 나왔는지" 단어별 기여도를 시각화.
 *
 * 사용 예:
 *   <SentimentExplanation explanation={data.explanation} />
 *
 * explanation 형식 (백엔드 schemas.WordContribution):
 *   [{ word: "차세대 양산 계획", contribution: 0.31 }, ...]
 *   contribution 양수 = 긍정 기여, 음수 = 부정 기여
 */
export default function SentimentExplanation({ explanation }) {
  if (!explanation || explanation.length === 0) return null

  const maxAbs = Math.max(...explanation.map((e) => Math.abs(e.contribution)), 0.01)

  return (
    <div
      style={{
        background: "var(--color-background-primary)",
        border: "0.5px solid var(--color-border-tertiary)",
        borderRadius: "var(--border-radius-lg)",
        padding: "1rem 1.25rem",
        marginTop: 16,
      }}
    >
      <p style={{ fontSize: 13, color: "var(--color-text-secondary)", margin: "0 0 12px" }}>
        왜 이렇게 판단했나요? — 기여도 상위 키워드
      </p>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {explanation.map((item, i) => {
          const widthPct = (Math.abs(item.contribution) / maxAbs) * 100
          const isPositive = item.contribution > 0
          const barColor = isPositive ? "#639922" : "#E24B4A"

          return (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 13, width: 120, flexShrink: 0 }}>{item.word}</span>
              <div
                style={{
                  flex: 1,
                  background: "var(--color-background-secondary)",
                  borderRadius: 4,
                  height: 18,
                }}
              >
                <div
                  style={{
                    width: `${widthPct}%`,
                    height: "100%",
                    background: barColor,
                    borderRadius: 4,
                  }}
                />
              </div>
              <span style={{ fontSize: 12, color: "var(--color-text-secondary)", width: 40 }}>
                {isPositive ? "+" : ""}
                {item.contribution.toFixed(2)}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
