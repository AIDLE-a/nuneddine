/**
 * [담당: 채민]
 * 백엔드 /api/analyze 호출 함수.
 * 응답 형식은 항상 schemas.py의 StockAnalysisResponse와 동일함.
 *
 * 사용 예:
 *   const data = await analyzeStock("005930.KS")
 *   data.confidence_score  // 68
 *   data.warnings          // ["뉴스 부족", "변동성 높음"]
 *   data.sentiment.positive
 *   data.prediction.future_price
 */
const API_BASE = "http://localhost:8000"

export async function analyzeStock(ticker) {
  const res = await fetch(`${API_BASE}/api/analyze?ticker=${encodeURIComponent(ticker)}`)
  if (!res.ok) {
    throw new Error(`분석 요청 실패: ${res.status}`)
  }
  return res.json()
}

/**
 * 응답 예시 (이 형태로 화면을 만들면 됨):
 * {
 *   "ticker": "005930.KS",
 *   "price": 72000,
 *   "news": [{ "title": "...", "source": "...", "url": "...", "published_at": "..." }],
 *   "prediction": { "future_price": 73500, "lower": 70000, "upper": 76000 },
 *   "sentiment": { "positive": 0.62, "negative": 0.31 },
 *   "warnings": ["뉴스 부족", "변동성 높음"],
 *   "confidence_score": 68
 * }
 */
