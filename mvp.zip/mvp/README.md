# 주식 리서치 MVP — 팀 운영 가이드

## 🎯 1개월 목표
**발표 가능한 MVP 완성**
종목 입력 → 뉴스 수집 → 감성 분석 → 예측 그래프 → uncertainty 경고 → 웹 UI 출력

LangGraph, RAG, GraphRAG, XAI는 MVP 이후 단계. 지금은 "철학이 보이는 MVP"가 목표.

---

## 👥 팀 역할

| 팀원 | 역할 | 담당 파일 |
|------|------|-----------|
| 희선 (A) | 시스템/백엔드 리더 — 전체 연결 책임자 | `backend/main.py` |
| 유빈 (B) | 데이터 수집 — yfinance, NewsAPI/RSS | `backend/services/data_service.py` |
| 연우 (C) | AI/ML — FinBERT, Prophet, uncertainty | `backend/services/ai_service.py` |
| 채민 (D) | 프론트엔드 — React/Vite, 차트, 신뢰도 UI | `frontend/src/*` |

---

## 🔗 API 계약 (1주차에 확정, 절대 임의 변경 금지)

`backend/schemas.py`에 Pydantic으로 고정되어 있음. 변경 필요 시 팀 전체 공유 후 수정.

```json
{
  "ticker": "005930.KS",
  "price": 72000,
  "news": [
    { "title": "...", "source": "...", "url": "...", "published_at": "..." }
  ],
  "prediction": { "future_price": 73500, "lower": 70000, "upper": 76000 },
  "sentiment": { "positive": 0.62, "negative": 0.31 },
  "warnings": ["뉴스 부족", "변동성 높음"],
  "confidence_score": 68
}
```

### 병렬 개발이 가능한 이유
`USE_MOCK_DATA=true` (기본값)일 때 `data_service.py`와 `ai_service.py`가 가짜 데이터를 반환함.
→ 유빈·연우가 진짜 API 연결을 끝내기 전에도 희선(서버 연결)과 채민(프론트)이 동시에 개발 가능.

진짜 데이터로 전환하려면 `.env`에 `USE_MOCK_DATA=false` 설정.

---

## 📅 4주 계획

### 1주차 — 각 기능 단독 성공
- 희선: FastAPI 기본 서버, `/api/analyze` 목업 응답 확인
- 유빈: yfinance + NewsAPI 연결, `_fetch_price` / `_fetch_news` 구현
- 연우: FinBERT 테스트, Prophet 예측 단독 성공
- 채민: React 기본 페이지, `api.js`로 목업 데이터 받아 화면 출력
- **팀 전체**: JSON 구조 확정 (이미 완료됨 ✅)

### 2주차 — 전체 연결
- 목표: 종목 입력 → 실제 데이터로 결과 출력
- `USE_MOCK_DATA=false`로 전환, API 연결 / 데이터 흐름 / 프론트 표시 전부 붙이기

### 3주차 — uncertainty 시스템 (프로젝트 정체성)
- `_calc_warnings`, `_calc_confidence` 로직 고도화
- 뉴스 부족 / 감성 충돌 / 변동성 증가 → 경고 생성 정교화

### 4주차 — 발표 가능한 MVP 완성
- UI 다듬기, 속도 개선, 오류 처리, 데모 시나리오 준비

---

## ✅ 매주 필수 — 통합 테스트

**토요일마다 반드시**: "삼성전자" 입력 → 전체 동작 확인.
이거 빼먹으면 마지막 주에 다 터짐.

### 운영 방식
- 화요일: 진행 공유 (짧게)
- 토요일: 통합 테스트
- 관리: Notion (문서) + GitHub Projects (이슈/역할)

---

## 🚀 실행 방법

```bash
# 백엔드
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
# http://localhost:8000/api/analyze?ticker=005930.KS

# 프론트엔드 (채민)
cd frontend
npm install
npm run dev
```

---

## 💡 기술 현실 버전 (무조건 간단하게 시작)

| 영역 | MVP 단계 | 이후 단계 |
|------|----------|-----------|
| 감성 분석 | HuggingFace pretrained FinBERT | 파인튜닝 |
| 예측 | Prophet 기본 | - |
| 멀티 에이전트 | Python 함수 분리 (`services/`) | LangGraph |
| 메모리 | 없음 | RAG (MVP 이후) |

---

## 🧭 핵심 원칙

> 이 프로젝트는 "기술을 얼마나 많이 넣었냐"가 아니라
> **"AI의 신뢰성을 얼마나 설득력 있게 보여주냐"**가 핵심.
>
> 1개월 목표는 "기술 데모"가 아니라 **"철학이 보이는 MVP"**.
